"""Generate a synthetic, deliberately messy telecom/subscription churn dataset.

Three raw tables are written to data/raw/:
  customers_profile.csv  one row per customer (plus injected duplicates)
  customers_accounts.csv one row per customer: plan, contract, billing, target
  customers_usage.csv    monthly usage, 6 months per customer (long format)

Injected data-quality problems (all documented/handled in the notebook):
  * missing values in every table
  * exact duplicate rows and duplicated customer_ids
  * inconsistent category spellings ("M", "male ", "MALE", ...)
  * impossible values (age 999, negative charges/usage) and heavy outliers
  * a leakage trap: cancellation_reason / account_closed_date exist only for churners

Run:  python src/generate_data.py
"""
from pathlib import Path

import numpy as np
import pandas as pd

SEED = 42
N = 5000
TARGET_CHURN_RATE = 0.23
SNAPSHOT = pd.Timestamp("2026-06-30")  # observation window ends here; churn is observed AFTER it

rng = np.random.default_rng(SEED)
OUT = Path(__file__).resolve().parents[1] / "data" / "raw"
OUT.mkdir(parents=True, exist_ok=True)


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def messy(values, variants, p=0.35):
    """Replace a share of clean labels with sloppy spellings."""
    out = []
    for v in values:
        if v in variants and rng.random() < p:
            out.append(rng.choice(variants[v]))
        else:
            out.append(v)
    return np.array(out, dtype=object)


ids = np.array([f"C{100000 + i}" for i in range(N)])

# ---------------------------------------------------------------- latent drivers
contract = rng.choice(["Month-to-month", "One year", "Two year"], N, p=[0.55, 0.25, 0.20])
plan = rng.choice(["Basic", "Standard", "Premium"], N, p=[0.45, 0.35, 0.20])
pay = rng.choice(["Credit Card", "Debit Card", "UPI", "Net Banking", "Auto-debit"], N,
                 p=[0.22, 0.20, 0.28, 0.12, 0.18])
referral = rng.choice(["Organic", "Referral", "Paid", "Partner"], N, p=[0.40, 0.25, 0.25, 0.10])
paperless = rng.choice([1, 0], N, p=[0.6, 0.4])
age = np.clip(rng.normal(41, 13, N), 18, 80).round().astype(int)

tenure_scale = np.where(contract == "Month-to-month", 10, np.where(contract == "One year", 20, 30))
tenure = np.clip(rng.gamma(2.0, tenure_scale), 1, 72).round().astype(int)

base_charge = pd.Series(plan).map({"Basic": 20.0, "Standard": 45.0, "Premium": 80.0}).to_numpy()
charges = np.clip(base_charge + rng.normal(0, 6, N), 8, None).round(2)

friction = rng.gamma(1.5, 0.6, N)  # latent unhappiness with service
tickets = rng.poisson(0.6 + 1.1 * friction)
late = rng.poisson(0.3 + 0.5 * friction)

# ---------------------------------------------------------------- churn model
z = (
    1.10 * (contract == "Month-to-month")
    - 0.90 * (contract == "Two year")
    - 0.035 * tenure
    + 0.025 * (charges - 45)
    + 0.28 * tickets
    + 0.35 * late
    - 0.50 * (pay == "Auto-debit")
    + 0.25 * (referral == "Paid")
    + 0.20 * paperless
    - 0.35 * (plan == "Premium")
    + 0.010 * (40 - age)
    + rng.normal(0, 0.9, N)
)
lo, hi = -10.0, 10.0
for _ in range(60):  # bisection on the intercept to hit the target churn rate
    mid = (lo + hi) / 2
    if sigmoid(z + mid).mean() > TARGET_CHURN_RATE:
        hi = mid
    else:
        lo = mid
p_churn = sigmoid(z + mid)
churn = rng.random(N) < p_churn

# ---------------------------------------------------------------- usage (6 months)
plan_level = pd.Series(plan).map({"Basic": 14.0, "Standard": 20.0, "Premium": 28.0}).to_numpy()
base_logins = plan_level * rng.lognormal(0, 0.45, N)
# Usage declines over the window in proportion to latent churn propensity (not the realised outcome)
slope = -0.16 * p_churn + rng.normal(0, 0.035, N)
session_len = rng.lognormal(np.log(24), 0.25, N)

rows = []
for i in range(N):
    for m in range(1, 7):
        level = max(base_logins[i] * (1 + slope[i] * (m - 1)) * rng.lognormal(0, 0.12), 0)
        logins = rng.poisson(level)
        minutes = logins * session_len[i] * rng.lognormal(0, 0.15)
        rows.append((ids[i], m, logins, round(minutes, 1),
                     round(minutes * rng.lognormal(-3.2, 0.3) , 2),
                     int(min(12, rng.poisson(2 + 0.12 * level)))))
usage = pd.DataFrame(rows, columns=["customer_id", "month", "logins", "minutes_used",
                                    "data_gb", "features_used"])

# ---------------------------------------------------------------- PROFILE table
signup = [SNAPSHOT - pd.DateOffset(months=int(t)) for t in tenure]
profile = pd.DataFrame({
    "customer_id": ids,
    "age": age.astype(float),
    "gender": messy(rng.choice(["Male", "Female", "Other"], N, p=[0.49, 0.49, 0.02]),
                    {"Male": ["M", "male", "Male ", "MALE"], "Female": ["F", "female", "FEMALE", " Female"]}),
    "region": messy(rng.choice(["North", "South", "East", "West", "Central"], N),
                    {r: [r.lower(), r.upper(), f" {r}"] for r in ["North", "South", "East", "West", "Central"]},
                    p=0.25),
    "signup_date": [d.strftime("%Y-%m-%d") for d in signup],
    "referral_source": referral,
})
# missing + invalid values
profile.loc[rng.random(N) < 0.04, "age"] = np.nan
bad = rng.choice(N, 8, replace=False)
profile.loc[bad, "age"] = rng.choice([0, -1, 150, 999, 5], 8)
profile.loc[rng.random(N) < 0.04, "gender"] = np.nan
profile.loc[rng.random(N) < 0.02, "signup_date"] = np.nan
profile.loc[rng.random(N) < 0.03, "referral_source"] = np.nan
# exact duplicates
profile = pd.concat([profile, profile.sample(150, random_state=SEED)], ignore_index=True)
profile = profile.sample(frac=1, random_state=SEED).reset_index(drop=True)

# ---------------------------------------------------------------- ACCOUNTS table
reasons = np.where(
    charges > np.percentile(charges, 60),
    rng.choice(["Price", "Competitor offer"], N, p=[0.6, 0.4]),
    rng.choice(["Service quality", "Moved", "Competitor offer", "Other"], N, p=[0.35, 0.2, 0.25, 0.2]),
)
closed = [SNAPSHOT + pd.Timedelta(days=int(d)) for d in rng.integers(1, 60, N)]
accounts = pd.DataFrame({
    "customer_id": ids,
    "plan_type": messy(plan, {"Basic": ["basic", "BASIC", "Basic "], "Standard": ["standard", "Std", "STANDARD"],
                              "Premium": ["premium", "PREMIUM", "Prem"]}),
    "contract_type": messy(contract, {"Month-to-month": ["month to month", "Monthly", "month-to-month", "M2M"],
                                      "One year": ["1 year", "One Year", "1-year"],
                                      "Two year": ["2 year", "Two Year", "2-year"]}),
    "payment_method": messy(pay, {"Credit Card": ["credit card", "CC"], "Debit Card": ["debit card", "DC"],
                                  "UPI": ["upi"], "Net Banking": ["netbanking", "net banking"],
                                  "Auto-debit": ["auto debit", "AutoDebit"]}, p=0.25),
    "paperless_billing": messy(np.where(paperless == 1, "Yes", "No"),
                               {"Yes": ["yes", "Y", "TRUE"], "No": ["no", "N", "FALSE"]}),
    "tenure_months": tenure.astype(float),
    "monthly_charges": charges,
    "support_tickets_6m": tickets,
    "late_payments_6m": late,
    "churned": messy(np.where(churn, "Yes", "No"), {"Yes": ["yes", "Y", "1"], "No": ["no", "N", "0"]}, p=0.1),
    # --- LEAKAGE TRAP: only exist because the customer already left ---
    "cancellation_reason": np.where(churn, reasons, None),
    "account_closed_date": [d.strftime("%Y-%m-%d") if c else None for d, c in zip(closed, churn)],
})
accounts.loc[rng.random(N) < 0.03, "tenure_months"] = np.nan
accounts.loc[rng.random(N) < 0.03, "monthly_charges"] = np.nan
accounts.loc[rng.random(N) < 0.03, "payment_method"] = np.nan
accounts.loc[rng.random(N) < 0.02, "paperless_billing"] = np.nan
accounts.loc[rng.random(N) < 0.02, "support_tickets_6m"] = np.nan
accounts.loc[rng.random(N) < 0.02, "late_payments_6m"] = np.nan
accounts.loc[rng.random(N) < 0.003, "churned"] = np.nan  # unlabeled rows
# data-entry outliers / impossible values in charges
big = rng.choice(N, 20, replace=False)
accounts.loc[big, "monthly_charges"] = accounts.loc[big, "monthly_charges"] * 10
neg = rng.choice(N, 5, replace=False)
accounts.loc[neg, "monthly_charges"] = -accounts.loc[neg, "monthly_charges"]
# duplicated customer_id with conflicting values (one row sloppier than the other)
dups = accounts.sample(60, random_state=SEED).copy()
dups["monthly_charges"] = np.nan
dups["payment_method"] = np.nan
accounts = pd.concat([accounts, dups], ignore_index=True).sample(frac=1, random_state=SEED).reset_index(drop=True)

# ---------------------------------------------------------------- USAGE defects
usage = usage.astype({"logins": float, "minutes_used": float, "data_gb": float, "features_used": float})
usage = usage[rng.random(len(usage)) > 0.03].copy()                      # missing months
usage.loc[rng.random(len(usage)) < 0.02, "minutes_used"] = np.nan
usage.loc[rng.random(len(usage)) < 0.015, "data_gb"] = np.nan
spike = usage.sample(60, random_state=SEED).index
usage.loc[spike, "minutes_used"] = usage.loc[spike, "minutes_used"] * 8      # heavy outliers
imp = usage.sample(10, random_state=SEED + 1).index
usage.loc[imp, "minutes_used"] = -usage.loc[imp, "minutes_used"].abs()       # impossible
usage = usage[~usage["customer_id"].isin(rng.choice(ids, 40, replace=False))]  # customers with no usage at all
usage = pd.concat([usage, usage.sample(120, random_state=SEED)], ignore_index=True)
usage = usage.sample(frac=1, random_state=SEED).reset_index(drop=True)

profile.to_csv(OUT / "customers_profile.csv", index=False)
accounts.to_csv(OUT / "customers_accounts.csv", index=False)
usage.to_csv(OUT / "customers_usage.csv", index=False)

print(f"profile  {profile.shape}  accounts {accounts.shape}  usage {usage.shape}")
print(f"true churn rate: {churn.mean():.3f}")
