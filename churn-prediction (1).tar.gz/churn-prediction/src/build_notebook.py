"""Build notebooks/churn_analysis.ipynb from src/churn_analysis.py (percent-format script).

Each `# %%` block becomes a cell. Code cells are executed in one shared namespace and their stdout,
last-expression value and matplotlib figures are stored as notebook outputs, so the notebook renders fully
on GitHub without needing to be re-run. Standard library + the analysis dependencies only (no nbformat needed).

Run from the repo root:   python src/build_notebook.py
Alternatively open src/churn_analysis.py with Jupytext, or just run the notebook top to bottom in Jupyter.
"""
import ast
import base64
import contextlib
import io
import json
import os
import re
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src" / "churn_analysis.py"
OUT = ROOT / "notebooks" / "churn_analysis.ipynb"


def split_cells(text):
    cells, kind, buf = [], None, []
    for line in text.splitlines():
        m = re.match(r"# %%( \[markdown\])?\s*$", line)
        if m:
            if kind:
                cells.append((kind, "\n".join(buf).strip("\n")))
            kind, buf = ("markdown" if m.group(1) else "code"), []
        else:
            buf.append(line)
    if kind:
        cells.append((kind, "\n".join(buf).strip("\n")))
    return cells


def md_source(body):
    return "\n".join(re.sub(r"^# ?", "", ln) for ln in body.splitlines())


def lines(s):
    parts = s.split("\n")
    return [p + "\n" for p in parts[:-1]] + [parts[-1]] if s else []


def main():
    os.chdir(ROOT / "notebooks")          # the notebook locates the project root from its own folder
    ns = {"__name__": "__main__"}
    figs = []

    def capture_show(*_, **__):
        for num in plt.get_fignums():
            buf = io.BytesIO()
            plt.figure(num).savefig(buf, format="png", dpi=110, bbox_inches="tight")
            figs.append(base64.b64encode(buf.getvalue()).decode())
        plt.close("all")

    plt.show = capture_show

    nb_cells, count = [], 0
    for kind, body in split_cells(SRC.read_text()):
        if kind == "markdown":
            nb_cells.append({"cell_type": "markdown", "metadata": {}, "source": lines(md_source(body))})
            continue
        count += 1
        outputs, figs[:] = [], []
        stdout = io.StringIO()
        tree = ast.parse(body)
        last = None
        if tree.body and isinstance(tree.body[-1], ast.Expr):
            last = ast.Expression(tree.body.pop().value)
        with contextlib.redirect_stdout(stdout):
            exec(compile(tree, f"cell{count}", "exec"), ns)
            value = eval(compile(last, f"cell{count}", "eval"), ns) if last is not None else None
        if stdout.getvalue():
            outputs.append({"output_type": "stream", "name": "stdout", "text": lines(stdout.getvalue())})
        for png in figs:
            outputs.append({"output_type": "display_data", "metadata": {},
                            "data": {"image/png": png, "text/plain": ["<Figure>"]}})
        if value is not None:
            data = {"text/plain": lines(repr(value))}
            if hasattr(value, "_repr_html_"):
                data["text/html"] = lines(value._repr_html_())
            outputs.append({"output_type": "execute_result", "execution_count": count, "metadata": {}, "data": data})
        nb_cells.append({"cell_type": "code", "execution_count": count, "metadata": {},
                         "outputs": outputs, "source": lines(body)})
        print(f"cell {count:>2}: {len(outputs)} output(s)", file=sys.stderr)

    nb = {"cells": nb_cells, "nbformat": 4, "nbformat_minor": 5,
          "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
                       "language_info": {"name": "python", "version": sys.version.split()[0]}}}
    for i, c in enumerate(nb_cells):
        c["id"] = f"cell-{i:03d}"
    OUT.write_text(json.dumps(nb, indent=1))
    print(f"wrote {OUT.relative_to(ROOT)}  ({OUT.stat().st_size / 1e6:.1f} MB, {len(nb_cells)} cells)", file=sys.stderr)


if __name__ == "__main__":
    main()
